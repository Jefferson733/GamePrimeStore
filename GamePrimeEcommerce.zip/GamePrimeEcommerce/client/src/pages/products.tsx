import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation, useParams } from 'wouter';
import { Helmet } from 'react-helmet';
import { Product } from '@shared/schema';
import ProductGrid from '@/components/products/ProductGrid';
import ProductFilters from '@/components/products/ProductFilters';

export default function Products() {
  const [, setLocation] = useLocation();
  const params = useParams<{ categorySlug?: string }>();
  const location = window.location;
  
  // Get search params
  const searchParams = new URLSearchParams(location.search);
  const searchQuery = searchParams.get('search');
  
  // State for filters
  const [selectedCategory, setSelectedCategory] = useState<string | null>(params.categorySlug || null);
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 5000]);
  
  // Fetch products based on filters
  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ['/api/products', selectedCategory, searchQuery, selectedBrands],
    queryFn: async () => {
      let url = '/api/products';
      
      if (selectedCategory) {
        url += `?category=${selectedCategory}`;
      } else if (searchQuery) {
        url += `?search=${searchQuery}`;
      }
      
      const res = await fetch(url);
      if (!res.ok) throw new Error('Failed to fetch products');
      
      const data = await res.json();
      
      // Filter by brand and price client-side
      return data.filter((product: Product) => {
        const price = parseFloat(product.price.toString());
        const matchesBrand = selectedBrands.length === 0 || selectedBrands.includes(product.brand);
        const matchesPrice = price >= priceRange[0] && price <= priceRange[1];
        
        return matchesBrand && matchesPrice;
      });
    }
  });

  // Update URL when category changes
  useEffect(() => {
    if (selectedCategory) {
      setLocation(`/products/${selectedCategory}`);
    } else if (searchQuery) {
      setLocation(`/products?search=${searchQuery}`);
    } else {
      setLocation('/products');
    }
  }, [selectedCategory, setLocation, searchQuery]);

  // Scroll to top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Handle category change
  const handleCategoryChange = (category: string | null) => {
    setSelectedCategory(category);
  };

  // Find max price for filter range
  const maxPrice = products.length > 0
    ? Math.max(...products.map(p => parseFloat(p.price.toString()))) + 100
    : 5000;

  // Page title based on category or search
  let pageTitle = 'Todos os Produtos - GamePrime Store';
  let pageDescription = 'Encontre os melhores equipamentos gaming na GamePrime Store.';
  
  if (selectedCategory) {
    pageTitle = `${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)} - GamePrime Store`;
    pageDescription = `Melhores ${selectedCategory} com descontos exclusivos na GamePrime Store.`;
  } else if (searchQuery) {
    pageTitle = `Resultados para "${searchQuery}" - GamePrime Store`;
    pageDescription = `Resultados da pesquisa por "${searchQuery}" na GamePrime Store.`;
  }

  return (
    <>
      <Helmet>
        <title>{pageTitle}</title>
        <meta name="description" content={pageDescription} />
        <meta property="og:title" content={pageTitle} />
        <meta property="og:description" content={pageDescription} />
        <meta property="og:type" content="website" />
      </Helmet>

      <section className="py-12 bg-gradient-to-b from-[var(--dark)] to-[var(--dark-lighter)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-poppins font-bold mb-2">
            {searchQuery 
              ? `Resultados para "${searchQuery}"` 
              : selectedCategory 
                ? selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)
                : 'Todos os Produtos'}
          </h1>
          <p className="text-gray-400 mb-8">
            {searchQuery 
              ? `Encontramos ${products.length} produtos relacionados à sua busca` 
              : 'Encontre os melhores equipamentos para o seu setup'}
          </p>
          
          {/* Filters and Products Grid Container */}
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Filters */}
            <ProductFilters 
              selectedCategory={selectedCategory}
              selectedBrands={selectedBrands}
              priceRange={priceRange}
              maxPrice={maxPrice}
              onCategoryChange={handleCategoryChange}
              onBrandChange={setSelectedBrands}
              onPriceChange={setPriceRange}
            />
            
            {/* Products Grid */}
            <ProductGrid 
              products={products} 
              isLoading={isLoading}
            />
          </div>
        </div>
      </section>
    </>
  );
}
