import { useEffect } from 'react';
import { useParams, Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Helmet } from 'react-helmet';
import { FaCheckCircle, FaHome, FaShoppingBag, FaSpinner } from 'react-icons/fa';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';

interface OrderItem {
  id: number;
  orderId: number;
  productId: number;
  name: string;
  price: string;
  quantity: number;
}

interface Order {
  id: number;
  customerName: string;
  email: string;
  address: string;
  city: string;
  state: string;
  postalCode: string;
  total: string;
  status: string;
  createdAt: string;
}

interface OrderResponse {
  order: Order;
  items: OrderItem[];
}

export default function OrderConfirmation() {
  const params = useParams<{ id: string }>();
  const orderId = parseInt(params.id);

  // Fetch order details
  const { data, isLoading, error } = useQuery<OrderResponse>({
    queryKey: [`/api/orders/${orderId}`],
    queryFn: async () => {
      const res = await fetch(`/api/orders/${orderId}`);
      if (!res.ok) {
        throw new Error('Failed to fetch order details');
      }
      return res.json();
    },
    enabled: !isNaN(orderId),
  });

  // Scroll to top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Format currency
  const formatCurrency = (value: string | number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(typeof value === 'string' ? parseFloat(value) : value);
  };

  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="py-20 flex justify-center items-center">
        <FaSpinner className="animate-spin text-4xl text-[var(--accent)]" />
      </div>
    );
  }

  // Error state
  if (error || !data) {
    return (
      <div className="py-20 max-w-3xl mx-auto px-4 text-center">
        <h1 className="text-2xl font-bold mb-4">Pedido não encontrado</h1>
        <p className="mb-6">Não conseguimos encontrar os detalhes deste pedido.</p>
        <div className="flex justify-center gap-4">
          <Link href="/">
            <Button variant="default">
              <FaHome className="mr-2" />
              Voltar para Início
            </Button>
          </Link>
          <Link href="/products">
            <Button variant="outline">
              <FaShoppingBag className="mr-2" />
              Continuar Comprando
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const { order, items } = data;

  return (
    <>
      <Helmet>
        <title>Pedido Confirmado - GamePrimeStore</title>
        <meta name="description" content="Seu pedido foi recebido e está sendo processado. Obrigado por comprar na GamePrimeStore!" />
        <meta property="og:title" content="Pedido Confirmado - GamePrimeStore" />
        <meta property="og:description" content="Seu pedido foi recebido e está sendo processado. Obrigado por comprar na GamePrimeStore!" />
        <meta property="og:type" content="website" />
      </Helmet>

      <section className="py-12 bg-[var(--dark)]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[var(--dark-lighter)] rounded-xl p-8 shadow-lg">
            {/* Confirmation Header */}
            <div className="text-center mb-8">
              <FaCheckCircle className="text-[var(--success)] text-5xl mx-auto mb-4" />
              <h1 className="text-2xl font-poppins font-bold mb-2">Pedido Confirmado!</h1>
              <p className="text-gray-400">
                Obrigado por comprar na GamePrime Store. Seu pedido foi recebido e está sendo processado.
              </p>
            </div>

            {/* Order Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div>
                <h2 className="font-semibold mb-2">Informações do Pedido</h2>
                <ul className="space-y-1 text-sm">
                  <li><span className="text-gray-400">Número do Pedido:</span> #{order.id}</li>
                  <li><span className="text-gray-400">Data:</span> {formatDate(order.createdAt)}</li>
                  <li><span className="text-gray-400">Status:</span> <span className="text-[var(--success)]">Confirmado</span></li>
                  <li><span className="text-gray-400">Total:</span> {formatCurrency(order.total)}</li>
                </ul>
              </div>

              <div>
                <h2 className="font-semibold mb-2">Informações de Entrega</h2>
                <ul className="space-y-1 text-sm">
                  <li><span className="text-gray-400">Nome:</span> {order.customerName}</li>
                  <li><span className="text-gray-400">Email:</span> {order.email}</li>
                  <li><span className="text-gray-400">Endereço:</span> {order.address}</li>
                  <li><span className="text-gray-400">Cidade/Estado:</span> {order.city}, {order.state}</li>
                  <li><span className="text-gray-400">CEP:</span> {order.postalCode}</li>
                </ul>
              </div>
            </div>

            <Separator className="my-6" />

            {/* Order Items */}
            <div>
              <h2 className="font-semibold mb-4">Itens do Pedido</h2>
              <div className="space-y-4">
                {items.map((item) => (
                  <div key={item.id} className="flex justify-between items-center">
                    <div className="flex items-start">
                      <span className="text-[var(--accent)] mr-2">{item.quantity}x</span>
                      <div>
                        <p className="font-medium">{item.name}</p>
                        <p className="text-sm text-gray-400">Preço unitário: {formatCurrency(item.price)}</p>
                      </div>
                    </div>
                    <span className="font-medium">{formatCurrency(parseFloat(item.price) * item.quantity)}</span>
                  </div>
                ))}
              </div>

              <Separator className="my-6" />

              {/* Order Total */}
              <div className="flex justify-end">
                <div className="w-full max-w-xs">
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-400">Subtotal:</span>
                    <span>{formatCurrency(order.total)}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-400">Frete:</span>
                    <span>Grátis</span>
                  </div>
                  <div className="flex justify-between font-bold">
                    <span>Total:</span>
                    <span className="text-[var(--accent)]">{formatCurrency(order.total)}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
              <Link href="/">
                <Button variant="default" className="w-full sm:w-auto">
                  <FaHome className="mr-2" />
                  Voltar para Início
                </Button>
              </Link>
              <Link href="/products">
                <Button variant="accent" className="w-full sm:w-auto">
                  <FaShoppingBag className="mr-2" />
                  Continuar Comprando
                </Button>
              </Link>
            </div>
          </div>

          {/* Shipping Information */}
          <div className="mt-8 bg-[var(--dark-lighter)] rounded-xl p-6 shadow-lg">
            <h2 className="font-semibold mb-4">Informações de Envio</h2>
            <p className="text-gray-400 text-sm mb-4">
              Seu pedido será enviado em até 2 dias úteis. Você receberá um email com o código de rastreamento assim que o pedido for despachado.
            </p>
            <div className="bg-[var(--primary)]/10 border border-[var(--primary)]/20 rounded-lg p-4">
              <p className="text-sm">
                Em caso de dúvidas sobre seu pedido, entre em contato conosco pelo email <span className="text-[var(--accent)]">suporte@gameprimestore.com.br</span> ou pelo telefone <span className="text-[var(--accent)]">(11) 99999-9999</span>.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
