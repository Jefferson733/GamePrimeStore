import { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Helmet } from 'react-helmet';
import { Product } from '@shared/schema';
import HeroSection from '@/components/home/HeroSection';
import CategorySection from '@/components/home/CategorySection';
import ProductGrid from '@/components/products/ProductGrid';
import PromoSection from '@/components/home/PromoSection';
import NewsletterSection from '@/components/home/NewsletterSection';

export default function Home() {
  // Fetch featured products
  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ['/api/products', 'featured'],
    queryFn: async () => {
      const res = await fetch('/api/products?featured=true');
      if (!res.ok) throw new Error('Failed to fetch featured products');
      return res.json();
    }
  });

  // Scroll to top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <Helmet>
        <title>GamePrime Store - Sua loja de produtos gamers</title>
        <meta name="description" content="GamePrime Store oferece os melhores equipamentos e acessórios gaming com preços imbatíveis. Consoles, headsets, teclados e mais!" />
        <meta property="og:title" content="GamePrime Store - Sua loja de produtos gamers" />
        <meta property="og:description" content="GamePrime Store oferece os melhores equipamentos e acessórios gaming com preços imbatíveis. Consoles, headsets, teclados e mais!" />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://gameprimestore.com.br" />
      </Helmet>

      <HeroSection />
      <CategorySection />

      <section id="products" className="py-12 bg-gradient-to-b from-[var(--dark)] to-[var(--dark-lighter)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-poppins font-bold mb-2">Produtos em destaque</h2>
          <p className="text-gray-400 mb-8">Encontre os melhores equipamentos para o seu setup</p>
          
          <ProductGrid products={products} isLoading={isLoading} />
        </div>
      </section>

      <PromoSection />
      <NewsletterSection />
    </>
  );
}
