import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { Helmet } from 'react-helmet';
import { useCart } from '@/lib/cartContext';
import CheckoutForm from '@/components/checkout/CheckoutForm';
import OrderSummary from '@/components/checkout/OrderSummary';

export default function Checkout() {
  const [, setLocation] = useLocation();
  const { cartItems } = useCart();

  // Redirect to products if cart is empty
  useEffect(() => {
    if (cartItems.length === 0) {
      setLocation('/products');
    }
  }, [cartItems, setLocation]);

  // Scroll to top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  if (cartItems.length === 0) {
    return null;
  }

  return (
    <>
      <Helmet>
        <title>Checkout - GamePrime Store</title>
        <meta name="description" content="Finalize sua compra na GamePrime Store. Pagamento seguro e entrega rápida para todo o Brasil." />
        <meta property="og:title" content="Checkout - GamePrime Store" />
        <meta property="og:description" content="Finalize sua compra na GamePrime Store. Pagamento seguro e entrega rápida para todo o Brasil." />
        <meta property="og:type" content="website" />
      </Helmet>

      <section className="py-12 bg-[var(--dark)]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-2xl font-poppins font-bold mb-8">Finalizar Compra</h1>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <CheckoutForm />
            </div>
            
            <div>
              <OrderSummary />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
