import { useEffect } from 'react';
import { useParams, useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Helmet } from 'react-helmet';
import { FaShoppingCart, FaSpinner } from 'react-icons/fa';
import { Product } from '@shared/schema';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { useCart } from '@/lib/cartContext';

export default function ProductDetail() {
  const params = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { addToCart } = useCart();

  // Fetch product details
  const { data: product, isLoading, error } = useQuery<Product>({
    queryKey: [`/api/products/${params.id}`],
    queryFn: async () => {
      const res = await fetch(`/api/products/${params.id}`);
      if (!res.ok) {
        throw new Error('Product not found');
      }
      return res.json();
    }
  });

  // Scroll to top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Format currency
  const formatCurrency = (value: string | number | undefined) => {
    if (value === undefined) return '';
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(typeof value === 'string' ? parseFloat(value) : value);
  };

  // Handle add to cart
  const handleAddToCart = () => {
    if (!product) return;
    
    addToCart({
      productId: product.id,
      name: product.name,
      price: parseFloat(product.price.toString()),
      image: product.image
    });
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="py-20 flex justify-center items-center">
        <FaSpinner className="animate-spin text-4xl text-[var(--accent)]" />
      </div>
    );
  }

  // Error state
  if (error || !product) {
    return (
      <div className="py-20 max-w-3xl mx-auto px-4 text-center">
        <h1 className="text-2xl font-bold mb-4">Produto não encontrado</h1>
        <p className="mb-6">O produto que você está procurando não está disponível.</p>
        <Button onClick={() => setLocation('/products')}>
          Voltar para produtos
        </Button>
      </div>
    );
  }

  // Calculate installment value (12x)
  const installmentValue = parseFloat(product.price.toString()) / 12;

  // Get category name
  const getCategoryName = (categoryId: number) => {
    switch (categoryId) {
      case 1: return 'Consoles';
      case 2: return 'Headsets';
      case 3: return 'Controles';
      case 4: return 'Teclados';
      case 5: return 'Mouses';
      default: return 'Acessórios';
    }
  };

  return (
    <>
      <Helmet>
        <title>{`${product.name} - GamePrime Store`}</title>
        <meta name="description" content={product.description} />
        <meta property="og:title" content={`${product.name} - GamePrime Store`} />
        <meta property="og:description" content={product.description} />
        <meta property="og:image" content={product.image} />
        <meta property="og:type" content="product" />
      </Helmet>

      <section className="py-12 bg-[var(--dark)]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[var(--dark-lighter)] rounded-xl overflow-hidden shadow-xl">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
              {/* Product Image */}
              <div className="flex items-center justify-center">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full max-w-md h-auto rounded-lg object-cover"
                />
              </div>
              
              {/* Product Details */}
              <div className="flex flex-col">
                <div className="mb-4">
                  <Badge variant="category" className="mb-4">
                    {getCategoryName(product.categoryId)}
                  </Badge>
                  <h1 className="text-3xl font-poppins font-bold">{product.name}</h1>
                  <p className="text-gray-400 mt-1">{product.brand}</p>
                </div>
                
                <Separator className="my-4" />
                
                <div className="mb-6">
                  <h3 className="font-medium mb-2">Descrição</h3>
                  <p className="text-gray-300">{product.description}</p>
                </div>
                
                <div className="mt-auto">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div>
                      <p className="text-[var(--accent)] font-bold text-3xl">
                        {formatCurrency(product.price)}
                      </p>
                      <p className="text-sm text-gray-400">
                        12x de {formatCurrency(installmentValue)} sem juros
                      </p>
                    </div>
                    <Button
                      variant="accent"
                      size="lg"
                      className="flex items-center gap-2"
                      onClick={handleAddToCart}
                    >
                      <FaShoppingCart />
                      Adicionar ao Carrinho
                    </Button>
                  </div>
                  
                  <p className="text-[var(--success)] text-xs mt-2">
                    {product.inStock ? 'Em estoque' : 'Sem estoque'}
                    {' • '}Frete grátis para compras acima de R$300
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
