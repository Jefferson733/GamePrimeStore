import { FaTruck, FaShieldAlt, FaHeadset } from 'react-icons/fa';

export default function PromoSection() {
  return (
    <section className="py-12 bg-[var(--dark)] border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-poppins font-bold text-center mb-12">Por que comprar na GamePrime?</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Feature 1 */}
          <div className="bg-[var(--dark-lighter)] rounded-xl p-6 text-center">
            <div className="w-16 h-16 rounded-full bg-[var(--primary)]/20 text-[var(--accent)] mx-auto flex items-center justify-center mb-4">
              <FaTruck className="text-2xl" />
            </div>
            <h3 className="font-poppins font-semibold text-xl mb-2">Entrega Rápida</h3>
            <p className="text-gray-400">Receba seus produtos em até 48 horas em diversas regiões do Brasil.</p>
          </div>
          
          {/* Feature 2 */}
          <div className="bg-[var(--dark-lighter)] rounded-xl p-6 text-center">
            <div className="w-16 h-16 rounded-full bg-[var(--primary)]/20 text-[var(--accent)] mx-auto flex items-center justify-center mb-4">
              <FaShieldAlt className="text-2xl" />
            </div>
            <h3 className="font-poppins font-semibold text-xl mb-2">Garantia Estendida</h3>
            <p className="text-gray-400">Todos os produtos com garantia de fábrica e possibilidade de extensão.</p>
          </div>
          
          {/* Feature 3 */}
          <div className="bg-[var(--dark-lighter)] rounded-xl p-6 text-center">
            <div className="w-16 h-16 rounded-full bg-[var(--primary)]/20 text-[var(--accent)] mx-auto flex items-center justify-center mb-4">
              <FaHeadset className="text-2xl" />
            </div>
            <h3 className="font-poppins font-semibold text-xl mb-2">Suporte Especializado</h3>
            <p className="text-gray-400">Atendimento por especialistas em games para melhor experiência de compra.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
