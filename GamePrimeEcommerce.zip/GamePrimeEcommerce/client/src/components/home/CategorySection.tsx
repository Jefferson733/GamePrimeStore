import { useQuery } from '@tanstack/react-query';
import { FaSpinner } from 'react-icons/fa';
import { Category } from '@shared/schema';
import CategoryCard from '@/components/products/CategoryCard';

export default function CategorySection() {
  const { data: categories = [], isLoading } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  if (isLoading) {
    return (
      <section className="py-12 bg-[var(--dark)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-center">
          <FaSpinner className="animate-spin text-4xl text-[var(--accent)]" />
        </div>
      </section>
    );
  }

  return (
    <section className="py-12 bg-[var(--dark)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-poppins font-bold text-center mb-10">Categorias</h2>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {categories.slice(0, 4).map((category) => (
            <CategoryCard key={category.id} category={category} />
          ))}
        </div>
      </div>
    </section>
  );
}
