import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';

export default function NewsletterSection() {
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate email
    if (!email || !email.includes('@')) {
      toast({
        title: "Erro de validação",
        description: "Por favor, insira um email válido.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Inscrição confirmada",
        description: "Você foi inscrito em nossa newsletter com sucesso!",
      });
      setEmail('');
      setIsSubmitting(false);
    }, 1000);
  };

  return (
    <section className="py-12 bg-gradient-to-r from-[var(--primary)]/30 to-[var(--secondary)]/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-poppins font-bold mb-4">Fique por dentro das novidades</h2>
          <p className="text-gray-300 max-w-2xl mx-auto mb-8">
            Inscreva-se na nossa newsletter e receba atualizações sobre lançamentos, promoções exclusivas e dicas para gamers.
          </p>
          
          <form onSubmit={handleSubmit} className="max-w-md mx-auto">
            <div className="flex flex-col sm:flex-row gap-3">
              <Input
                type="email"
                placeholder="Seu melhor e-mail"
                className="flex-1 px-4 py-3 rounded-lg bg-[var(--dark)] border border-gray-700 text-[var(--light)] focus:outline-none focus:border-[var(--accent)] focus:ring-1 focus:ring-[var(--accent)]"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={isSubmitting}
              />
              <Button 
                type="submit" 
                variant="accent" 
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Inscrevendo...' : 'Inscrever-se'}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}
