import { Link } from 'wouter';
import { FaArrowRight } from 'react-icons/fa';
import { Button } from '@/components/ui/button';

export default function HeroSection() {
  return (
    <section className="relative">
      <div 
        className="h-[60vh] bg-cover bg-center" 
        style={{ 
          backgroundImage: "url('https://images.unsplash.com/photo-1593305841991-05c297ba4575?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&q=80')" 
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-[var(--dark)] to-transparent"></div>
        <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-center">
          <h1 className="font-poppins font-bold text-4xl md:text-5xl lg:text-6xl text-[var(--light)] max-w-lg">
            Eleve sua experiência gamer
          </h1>
          <p className="mt-4 text-lg md:text-xl text-[var(--light)] max-w-md">
            Equipamentos de alta performance e acessórios para o seu setup perfeito
          </p>
          <div className="mt-8">
            <Link href="/products">
              <Button variant="accent" size="lg" className="inline-flex items-center px-8 py-3">
                Ver produtos
                <FaArrowRight className="ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
