import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { FaChevronDown, FaChevronUp } from 'react-icons/fa';
import { Category } from '@shared/schema';
import { Separator } from '@/components/ui/separator';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';

interface ProductFiltersProps {
  selectedCategory: string | null;
  selectedBrands: string[];
  priceRange: [number, number];
  maxPrice: number;
  onCategoryChange: (category: string | null) => void;
  onBrandChange: (brands: string[]) => void;
  onPriceChange: (range: [number, number]) => void;
}

export default function ProductFilters({
  selectedCategory,
  selectedBrands,
  priceRange,
  maxPrice,
  onCategoryChange,
  onBrandChange,
  onPriceChange
}: ProductFiltersProps) {
  const [isMobileFiltersOpen, setIsMobileFiltersOpen] = useState(false);
  const [localPriceRange, setLocalPriceRange] = useState<[number, number]>(priceRange);
  
  // Get categories from API
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  // All available brands (usually this would come from API)
  const brands = ["Sony", "Microsoft", "Nintendo", "Razer", "Logitech", "HyperX", "Corsair", "SteelSeries"];

  // Update price range when props change
  useEffect(() => {
    setLocalPriceRange(priceRange);
  }, [priceRange]);

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Handle price change from slider
  const handlePriceSliderChange = (value: number[]) => {
    const newRange: [number, number] = [value[0], value[1] || maxPrice];
    setLocalPriceRange(newRange);
    onPriceChange(newRange);
  };

  // Toggle brand selection
  const toggleBrand = (brand: string) => {
    if (selectedBrands.includes(brand)) {
      onBrandChange(selectedBrands.filter(b => b !== brand));
    } else {
      onBrandChange([...selectedBrands, brand]);
    }
  };

  return (
    <>
      {/* Mobile Filters - Collapsible */}
      <div className="lg:hidden w-full mb-4">
        <button 
          onClick={() => setIsMobileFiltersOpen(!isMobileFiltersOpen)}
          className="w-full bg-[var(--dark-lighter)] rounded-lg p-4 flex justify-between items-center"
        >
          <span className="font-medium">Filtros</span>
          {isMobileFiltersOpen ? (
            <FaChevronUp className="text-gray-400" />
          ) : (
            <FaChevronDown className="text-gray-400" />
          )}
        </button>
        
        {isMobileFiltersOpen && (
          <div className="bg-[var(--dark-lighter)] rounded-lg p-4 mt-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Categories */}
              <div>
                <h4 className="font-medium mb-2">Categorias</h4>
                <select 
                  className="w-full bg-[var(--dark)] border border-gray-700 rounded-lg p-2 text-sm"
                  value={selectedCategory || ""}
                  onChange={(e) => onCategoryChange(e.target.value === "" ? null : e.target.value)}
                >
                  <option value="">Todos</option>
                  {categories.map(category => (
                    <option key={category.id} value={category.slug}>{category.name}</option>
                  ))}
                </select>
              </div>
              
              {/* Brands */}
              <div>
                <h4 className="font-medium mb-2">Marcas</h4>
                <select 
                  className="w-full bg-[var(--dark)] border border-gray-700 rounded-lg p-2 text-sm"
                  value={selectedBrands.length === 0 ? "" : selectedBrands[0]}
                  onChange={(e) => {
                    if (e.target.value === "") {
                      onBrandChange([]);
                    } else {
                      onBrandChange([e.target.value]);
                    }
                  }}
                >
                  <option value="">Todas</option>
                  {brands.map(brand => (
                    <option key={brand} value={brand}>{brand}</option>
                  ))}
                </select>
              </div>
              
              {/* Price Range */}
              <div className="col-span-1 md:col-span-2 mt-2">
                <h4 className="font-medium mb-2">Preço</h4>
                <Slider
                  value={[localPriceRange[0], localPriceRange[1]]}
                  min={0}
                  max={maxPrice}
                  step={50}
                  className="w-full"
                  onValueChange={handlePriceSliderChange}
                />
                <div className="flex justify-between mt-1">
                  <span className="text-xs text-gray-400">{formatCurrency(localPriceRange[0])}</span>
                  <span className="text-xs text-gray-400">{formatCurrency(localPriceRange[1])}</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Desktop Filters */}
      <div className="hidden lg:block w-64 bg-[var(--dark-lighter)] rounded-lg p-6 h-fit sticky top-24">
        <h3 className="font-poppins font-semibold text-xl mb-4">Filtros</h3>
        
        {/* Categories */}
        <div className="mb-6">
          <h4 className="font-medium text-lg mb-2">Categorias</h4>
          <RadioGroup 
            defaultValue={selectedCategory || ""} 
            onValueChange={(value) => onCategoryChange(value === "" ? null : value)}
          >
            <div className="space-y-2">
              <div className="flex items-center">
                <RadioGroupItem value="" id="category-all" />
                <Label htmlFor="category-all" className="ml-2">Todos</Label>
              </div>
              
              {categories.map(category => (
                <div key={category.id} className="flex items-center">
                  <RadioGroupItem value={category.slug} id={`category-${category.slug}`} />
                  <Label htmlFor={`category-${category.slug}`} className="ml-2">{category.name}</Label>
                </div>
              ))}
            </div>
          </RadioGroup>
        </div>
        
        <Separator className="my-4 bg-gray-800" />
        
        {/* Price Range */}
        <div className="mb-6">
          <h4 className="font-medium text-lg mb-2">Preço</h4>
          <div className="space-y-4">
            <Slider
              value={[localPriceRange[0], localPriceRange[1]]}
              min={0}
              max={maxPrice}
              step={50}
              className="w-full"
              onValueChange={handlePriceSliderChange}
            />
            <div className="flex justify-between">
              <span className="text-sm text-gray-400">{formatCurrency(localPriceRange[0])}</span>
              <span className="text-sm text-gray-400">{formatCurrency(localPriceRange[1])}</span>
            </div>
          </div>
        </div>
        
        <Separator className="my-4 bg-gray-800" />
        
        {/* Brands */}
        <div>
          <h4 className="font-medium text-lg mb-2">Marcas</h4>
          <div className="space-y-2">
            <div className="flex items-center">
              <Checkbox 
                id="brand-all" 
                checked={selectedBrands.length === 0}
                onCheckedChange={() => onBrandChange([])}
              />
              <Label htmlFor="brand-all" className="ml-2">Todas</Label>
            </div>
            
            {brands.map(brand => (
              <div key={brand} className="flex items-center">
                <Checkbox 
                  id={`brand-${brand}`} 
                  checked={selectedBrands.includes(brand)}
                  onCheckedChange={() => toggleBrand(brand)}
                />
                <Label htmlFor={`brand-${brand}`} className="ml-2">{brand}</Label>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
