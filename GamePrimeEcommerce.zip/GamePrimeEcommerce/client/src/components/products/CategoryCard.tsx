import { Link } from 'wouter';
import { Category } from '@shared/schema';

interface CategoryCardProps {
  category: Category;
}

export default function CategoryCard({ category }: CategoryCardProps) {
  return (
    <Link href={`/products/${category.slug}`}>
      <div className="group relative overflow-hidden rounded-xl bg-[var(--dark-lighter)] cursor-pointer">
        <div 
          className="aspect-square bg-cover bg-center transition duration-300 group-hover:scale-105"
          style={{ backgroundImage: `url(${category.image})` }}
        >
          <div className="w-full h-full bg-gradient-to-t from-[var(--dark-lighter)]/90 to-transparent flex items-end justify-center p-4">
            <h3 className="font-poppins font-semibold text-center text-lg">{category.name}</h3>
          </div>
        </div>
      </div>
    </Link>
  );
}
