import { useState } from 'react';
import { FaSpinner } from 'react-icons/fa';
import { Product } from '@shared/schema';
import ProductCard from '@/components/products/ProductCard';
import { Button } from '@/components/ui/button';

interface ProductGridProps {
  products: Product[];
  isLoading: boolean;
  hasMore?: boolean;
  onLoadMore?: () => void;
}

export default function ProductGrid({ 
  products, 
  isLoading, 
  hasMore = false,
  onLoadMore 
}: ProductGridProps) {
  const [loadingMore, setLoadingMore] = useState(false);

  const handleLoadMore = async () => {
    if (onLoadMore) {
      setLoadingMore(true);
      await onLoadMore();
      setLoadingMore(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-[400px] flex items-center justify-center">
        <FaSpinner className="animate-spin text-4xl text-[var(--accent)]" />
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="min-h-[400px] flex flex-col items-center justify-center bg-[var(--dark-lighter)] rounded-lg p-8">
        <h3 className="text-xl font-semibold mb-4">Nenhum produto encontrado</h3>
        <p className="text-gray-400 text-center mb-4">
          Tente ajustar os filtros ou buscar por outro termo.
        </p>
      </div>
    );
  }

  return (
    <div className="flex-1">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
      
      {hasMore && onLoadMore && (
        <div className="mt-10 text-center">
          <Button
            variant="load"
            onClick={handleLoadMore}
            disabled={loadingMore}
          >
            {loadingMore ? (
              <>
                Carregando...
                <FaSpinner className="animate-spin ml-2" />
              </>
            ) : (
              <>
                Carregar mais produtos
                <FaSpinner className="ml-2" />
              </>
            )}
          </Button>
        </div>
      )}
    </div>
  );
}
