import { Link } from 'wouter';
import { FaShoppingCart } from 'react-icons/fa';
import { Product } from '@shared/schema';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useCart } from '@/lib/cartContext';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();

  // Format currency
  const formatCurrency = (value: string | number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(typeof value === 'string' ? parseFloat(value) : value);
  };

  // Calculate installment value (12x)
  const installmentValue = parseFloat(product.price.toString()) / 12;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    addToCart({
      productId: product.id,
      name: product.name,
      price: parseFloat(product.price.toString()),
      image: product.image
    });
  };

  return (
    <Link href={`/product/${product.id}`}>
      <div className="bg-[var(--dark-lighter)] rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all hover:transform hover:scale-[1.02] duration-300 h-full flex flex-col">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-48 object-cover"
        />
        
        <div className="p-4 flex flex-col flex-grow">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-poppins font-semibold text-lg mb-1">{product.name}</h3>
              <p className="text-sm text-gray-400 mb-3">{product.brand}</p>
            </div>
            <Badge variant="category">
              {product.categoryId === 1 ? 'Consoles' : 
               product.categoryId === 2 ? 'Headsets' : 
               product.categoryId === 3 ? 'Controles' : 
               product.categoryId === 4 ? 'Teclados' : 'Acessórios'}
            </Badge>
          </div>
          
          <div className="flex justify-between items-center mt-auto">
            <div>
              <p className="text-[var(--accent)] font-bold text-xl">{formatCurrency(product.price)}</p>
              <p className="text-xs text-gray-400">12x de {formatCurrency(installmentValue)}</p>
            </div>
            <Button
              variant="cart"
              onClick={handleAddToCart}
              aria-label={`Add ${product.name} to cart`}
            >
              <FaShoppingCart />
            </Button>
          </div>
        </div>
      </div>
    </Link>
  );
}
