import { useCart } from "@/lib/cartContext";
import { Separator } from "@/components/ui/separator";

export default function OrderSummary() {
  const { cartItems, total } = useCart();
  
  // Calculate shipping and total
  const shippingCost = total >= 300 ? 0 : 30;
  const orderTotal = total + shippingCost;

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  return (
    <div className="bg-[var(--dark-lighter)] rounded-lg p-6">
      <h3 className="text-lg font-semibold mb-4">Resumo do Pedido</h3>
      
      <div className="space-y-4 mb-4">
        {cartItems.map((item) => (
          <div key={item.id} className="flex justify-between">
            <div className="flex items-start">
              <span className="text-[var(--accent)] mr-2">{item.quantity}x</span>
              <span className="text-sm">{item.name}</span>
            </div>
            <span className="text-sm font-medium">
              {formatCurrency(item.price * item.quantity)}
            </span>
          </div>
        ))}
      </div>
      
      <Separator className="my-4" />
      
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-gray-400">Subtotal</span>
          <span>{formatCurrency(total)}</span>
        </div>
        
        <div className="flex justify-between text-sm">
          <span className="text-gray-400">Frete</span>
          <span>{shippingCost === 0 ? 'Grátis' : formatCurrency(shippingCost)}</span>
        </div>
        
        {shippingCost === 0 && (
          <div className="text-xs text-[var(--success)] italic">
            Frete grátis para compras acima de {formatCurrency(300)}
          </div>
        )}
        
        <Separator className="my-2" />
        
        <div className="flex justify-between font-semibold">
          <span>Total</span>
          <span className="text-[var(--accent)] text-lg">{formatCurrency(orderTotal)}</span>
        </div>
      </div>
    </div>
  );
}
