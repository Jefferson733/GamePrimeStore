import { useEffect, useRef } from 'react';
import { Link } from 'wouter';
import { FaTimes, FaArrowRight } from 'react-icons/fa';
import { useCart } from '@/lib/cartContext';
import CartItem from '@/components/cart/CartItem';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';

export default function ShoppingCart() {
  const { cartItems, isCartOpen, closeCart, total } = useCart();
  const cartRef = useRef<HTMLDivElement>(null);

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Handle click outside to close cart
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (cartRef.current && !cartRef.current.contains(event.target as Node) && isCartOpen) {
        closeCart();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isCartOpen, closeCart]);

  // Handle scroll lock when cart is open
  useEffect(() => {
    if (isCartOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      document.body.style.overflow = '';
    };
  }, [isCartOpen]);

  // Shipping calculation (free for orders over R$300)
  const shippingCost = total >= 300 ? 0 : 30;
  const orderTotal = total + shippingCost;

  return (
    <div className={`fixed inset-0 z-50 overflow-hidden ${isCartOpen ? 'pointer-events-auto' : 'pointer-events-none'}`}>
      {/* Overlay */}
      <div 
        className={`absolute inset-0 bg-[var(--dark)] opacity-50 transition-opacity duration-300 ${isCartOpen ? 'opacity-50' : 'opacity-0'}`} 
        onClick={closeCart}
      />

      {/* Cart panel */}
      <div 
        ref={cartRef}
        className={`absolute right-0 top-0 bottom-0 w-full max-w-md bg-[var(--dark-lighter)] shadow-xl transform transition-transform duration-300 ${isCartOpen ? 'translate-x-0' : 'translate-x-full'}`}
      >
        {/* Cart Header */}
        <div className="p-4 border-b border-gray-800 flex justify-between items-center sticky top-0 bg-[var(--dark-lighter)] z-10">
          <h2 className="font-poppins font-semibold text-xl">Seu Carrinho</h2>
          <button 
            onClick={closeCart}
            className="text-gray-400 hover:text-[var(--light)]"
            aria-label="Close cart"
          >
            <FaTimes className="text-xl" />
          </button>
        </div>

        {/* Cart Items */}
        <div className="p-4 overflow-y-auto max-h-[calc(100vh-180px)] scrollbar-hide">
          {cartItems.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-400 mb-4">Seu carrinho está vazio</p>
              <Button variant="accent" onClick={closeCart}>
                Começar a comprar
              </Button>
            </div>
          ) : (
            cartItems.map((item) => (
              <CartItem key={item.id} item={item} />
            ))
          )}
        </div>

        {/* Cart Footer */}
        {cartItems.length > 0 && (
          <div className="border-t border-gray-800 p-4 bg-[var(--dark-lighter)] sticky bottom-0">
            <div className="mb-4 pb-4 border-b border-gray-800">
              <div className="flex justify-between mb-2">
                <span className="text-gray-400">Subtotal</span>
                <span>{formatCurrency(total)}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-400">Frete</span>
                <span>{shippingCost === 0 ? 'Grátis' : formatCurrency(shippingCost)}</span>
              </div>
              <div className="flex justify-between font-semibold">
                <span>Total</span>
                <span className="text-[var(--accent)]">{formatCurrency(orderTotal)}</span>
              </div>
            </div>

            <Link href="/checkout" onClick={closeCart}>
              <Button variant="checkout">
                Finalizar Compra
                <FaArrowRight className="ml-2" />
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
