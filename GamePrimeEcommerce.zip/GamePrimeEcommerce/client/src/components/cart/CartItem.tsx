import { FaTrashAlt, FaMinus, FaPlus } from 'react-icons/fa';
import { useCart } from '@/lib/cartContext';
import { CartItem as CartItemType } from '@shared/schema';

interface CartItemProps {
  item: CartItemType;
}

export default function CartItem({ item }: CartItemProps) {
  const { removeFromCart, updateQuantity } = useCart();

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  return (
    <div className="flex mb-4 pb-4 border-b border-gray-800">
      <img 
        src={item.image} 
        alt={item.name} 
        className="w-20 h-20 object-cover rounded-lg"
      />
      
      <div className="ml-4 flex-1">
        <div className="flex justify-between">
          <h3 className="font-medium">{item.name}</h3>
          <button 
            className="text-gray-400 hover:text-[var(--error)]"
            onClick={() => removeFromCart(item.id)}
            aria-label="Remove item"
          >
            <FaTrashAlt />
          </button>
        </div>
        
        <div className="flex justify-between items-center mt-2">
          <div className="flex items-center border border-gray-700 rounded-lg">
            <button 
              className="px-2 py-1 text-gray-400 hover:text-[var(--light)]"
              onClick={() => updateQuantity(item.id, Math.max(1, item.quantity - 1))}
              aria-label="Decrease quantity"
            >
              <FaMinus className="text-xs" />
            </button>
            <span className="px-2 text-sm">{item.quantity}</span>
            <button 
              className="px-2 py-1 text-gray-400 hover:text-[var(--light)]"
              onClick={() => updateQuantity(item.id, item.quantity + 1)}
              aria-label="Increase quantity"
            >
              <FaPlus className="text-xs" />
            </button>
          </div>
          <p className="font-medium text-[var(--accent)]">
            {formatCurrency(item.price * item.quantity)}
          </p>
        </div>
      </div>
    </div>
  );
}
