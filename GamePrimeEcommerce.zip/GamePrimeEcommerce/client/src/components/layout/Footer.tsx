import { Link } from 'wouter';
import { 
  FaGamepad, 
  FaInstagram, 
  FaFacebook, 
  FaTwitter, 
  FaYoutube,
  FaMapMarkerAlt,
  FaPhone,
  FaEnvelope,
  FaClock
} from 'react-icons/fa';

export default function Footer() {
  return (
    <footer className="bg-[var(--dark-lighter)] py-12 border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center mb-4">
              <FaGamepad className="text-[var(--accent)] text-2xl mr-2" />
              <span className="font-poppins font-bold text-xl">GamePrime</span>
            </div>
            <p className="text-gray-400 mb-4">
              A sua loja de produtos gamers com os melhores preços e condições do mercado.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-[var(--accent)] transition-colors">
                <FaInstagram className="text-xl" />
              </a>
              <a href="#" className="text-gray-400 hover:text-[var(--accent)] transition-colors">
                <FaFacebook className="text-xl" />
              </a>
              <a href="#" className="text-gray-400 hover:text-[var(--accent)] transition-colors">
                <FaTwitter className="text-xl" />
              </a>
              <a href="#" className="text-gray-400 hover:text-[var(--accent)] transition-colors">
                <FaYoutube className="text-xl" />
              </a>
            </div>
          </div>
          
          {/* Links 1 */}
          <div>
            <h3 className="font-poppins font-semibold text-lg mb-4">Categorias</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/products/consoles" className="text-gray-400 hover:text-[var(--accent)] transition-colors">
                  Consoles
                </Link>
              </li>
              <li>
                <Link href="/products/headsets" className="text-gray-400 hover:text-[var(--accent)] transition-colors">
                  Headsets
                </Link>
              </li>
              <li>
                <Link href="/products/controllers" className="text-gray-400 hover:text-[var(--accent)] transition-colors">
                  Controles
                </Link>
              </li>
              <li>
                <Link href="/products/keyboards" className="text-gray-400 hover:text-[var(--accent)] transition-colors">
                  Teclados
                </Link>
              </li>
              <li>
                <Link href="/products/mice" className="text-gray-400 hover:text-[var(--accent)] transition-colors">
                  Mouses
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Links 2 */}
          <div>
            <h3 className="font-poppins font-semibold text-lg mb-4">Atendimento</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-gray-400 hover:text-[var(--accent)] transition-colors">
                  Central de Ajuda
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-[var(--accent)] transition-colors">
                  Política de Privacidade
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-[var(--accent)] transition-colors">
                  Termos de Uso
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-[var(--accent)] transition-colors">
                  Trocas e Devoluções
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-[var(--accent)] transition-colors">
                  Fale Conosco
                </a>
              </li>
            </ul>
          </div>
          
          {/* Contact */}
          <div>
            <h3 className="font-poppins font-semibold text-lg mb-4">Contato</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <FaMapMarkerAlt className="text-[var(--accent)] mt-1 mr-2" />
                <span className="text-gray-400">Av. Paulista, 1000 - São Paulo/SP</span>
              </li>
              <li className="flex items-center">
                <FaPhone className="text-[var(--accent)] mr-2" />
                <span className="text-gray-400">(11) 99999-9999</span>
              </li>
              <li className="flex items-center">
                <FaEnvelope className="text-[var(--accent)] mr-2" />
                <span className="text-gray-400">contato@gameprimestore.com.br</span>
              </li>
              <li className="flex items-center">
                <FaClock className="text-[var(--accent)] mr-2" />
                <span className="text-gray-400">Seg a Sex: 9h às 18h</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8 text-center text-gray-400 text-sm">
          <p>&copy; {new Date().getFullYear()} GamePrime Store. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
