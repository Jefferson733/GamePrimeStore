import { useState, useEffect } from 'react';
import { Link, useRoute } from 'wouter';
import { FaGamepad, FaShoppingCart, FaBars, FaSearch } from 'react-icons/fa';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useCart } from '@/lib/cartContext';

export default function Navbar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { cartItems, openCart } = useCart();
  const [isAtTop, setIsAtTop] = useState(true);

  const [isHomeMatch] = useRoute('/');
  const [isProductsMatch] = useRoute('/products');
  const [isConsolesMatch] = useRoute('/products/consoles');
  const [isAccessoriesMatch] = useRoute('/products/headsets');

  // Handle scroll events to add shadow to navbar when scrolled
  useEffect(() => {
    const handleScroll = () => {
      setIsAtTop(window.scrollY === 0);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Total items in cart
  const cartItemCount = cartItems.reduce((total, item) => total + item.quantity, 0);

  return (
    <header className={`bg-[var(--dark-lighter)] sticky top-0 z-50 ${!isAtTop ? 'shadow-lg' : ''}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-3">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <FaGamepad className="text-[var(--accent)] text-3xl mr-2" />
              <span className="font-poppins font-bold text-xl lg:text-2xl">GamePrime</span>
            </Link>
          </div>

          {/* Search bar - hidden on mobile, visible on larger screens */}
          <div className="hidden md:flex flex-1 mx-8">
            <div className="relative w-full max-w-lg">
              <Input
                type="text"
                placeholder="Buscar produtos..."
                className="w-full bg-[var(--dark)] py-2 pl-4 pr-10 rounded-lg text-[var(--light)] border border-gray-700 focus:outline-none focus:border-[var(--accent)] focus:ring-1 focus:ring-[var(--accent)]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && searchQuery.trim()) {
                    window.location.href = `/products?search=${encodeURIComponent(searchQuery)}`;
                  }
                }}
              />
              <Button 
                className="absolute right-3 top-2.5 text-gray-400"
                variant="ghost"
                size="sm"
                onClick={() => {
                  if (searchQuery.trim()) {
                    window.location.href = `/products?search=${encodeURIComponent(searchQuery)}`;
                  }
                }}
              >
                <FaSearch />
              </Button>
            </div>
          </div>

          {/* Navigation Links and Cart */}
          <div className="flex items-center space-x-6">
            {/* Navigation Links - Hidden on Mobile */}
            <nav className="hidden md:flex space-x-6">
              <Link href="/" className={`text-[var(--light)] ${isHomeMatch ? 'text-[var(--accent)]' : 'hover:text-[var(--accent)]'} font-medium transition-colors`}>
                Início
              </Link>
              <Link href="/products" className={`text-[var(--light)] ${isProductsMatch ? 'text-[var(--accent)]' : 'hover:text-[var(--accent)]'} font-medium transition-colors`}>
                Produtos
              </Link>
              <Link href="/products/consoles" className={`text-[var(--light)] ${isConsolesMatch ? 'text-[var(--accent)]' : 'hover:text-[var(--accent)]'} font-medium transition-colors`}>
                Consoles
              </Link>
              <Link href="/products/headsets" className={`text-[var(--light)] ${isAccessoriesMatch ? 'text-[var(--accent)]' : 'hover:text-[var(--accent)]'} font-medium transition-colors`}>
                Acessórios
              </Link>
            </nav>

            {/* Cart Button */}
            <button
              onClick={openCart}
              className="relative p-2 text-[var(--light)] hover:text-[var(--accent)] focus:outline-none transition-colors"
              aria-label="Open shopping cart"
            >
              <FaShoppingCart className="text-xl" />
              {cartItemCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[var(--accent)] text-[var(--dark)] text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                  {cartItemCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden text-[var(--light)] hover:text-[var(--accent)] focus:outline-none"
              aria-label={isMobileMenuOpen ? 'Close menu' : 'Open menu'}
            >
              <FaBars className="text-xl" />
            </button>
          </div>
        </div>

        {/* Search bar on mobile - always visible on mobile */}
        <div className="md:hidden pb-3">
          <div className="relative w-full">
            <Input
              type="text"
              placeholder="Buscar produtos..."
              className="w-full bg-[var(--dark)] py-2 pl-4 pr-10 rounded-lg text-[var(--light)] border border-gray-700 focus:outline-none focus:border-[var(--accent)] focus:ring-1 focus:ring-[var(--accent)]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && searchQuery.trim()) {
                  window.location.href = `/products?search=${encodeURIComponent(searchQuery)}`;
                }
              }}
            />
            <Button 
              className="absolute right-3 top-2.5 text-gray-400"
              variant="ghost"
              size="sm"
              onClick={() => {
                if (searchQuery.trim()) {
                  window.location.href = `/products?search=${encodeURIComponent(searchQuery)}`;
                }
              }}
            >
              <FaSearch />
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu - conditionally visible */}
      <div className={`md:hidden bg-[var(--dark-lighter)] border-t border-gray-800 ${isMobileMenuOpen ? 'block' : 'hidden'}`}>
        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
          <Link href="/" className="block px-3 py-2 rounded-md text-base font-medium text-[var(--light)] hover:bg-[var(--dark)] hover:text-[var(--accent)]">
            Início
          </Link>
          <Link href="/products" className="block px-3 py-2 rounded-md text-base font-medium text-[var(--light)] hover:bg-[var(--dark)] hover:text-[var(--accent)]">
            Produtos
          </Link>
          <Link href="/products/consoles" className="block px-3 py-2 rounded-md text-base font-medium text-[var(--light)] hover:bg-[var(--dark)] hover:text-[var(--accent)]">
            Consoles
          </Link>
          <Link href="/products/headsets" className="block px-3 py-2 rounded-md text-base font-medium text-[var(--light)] hover:bg-[var(--dark)] hover:text-[var(--accent)]">
            Acessórios
          </Link>
        </div>
      </div>
    </header>
  );
}
