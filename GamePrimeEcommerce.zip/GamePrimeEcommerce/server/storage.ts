import { 
  type Category, type InsertCategory, 
  type Product, type InsertProduct, 
  type Order, type InsertOrder,
  type OrderItem, type InsertOrderItem,
  type CartItem
} from "@shared/schema";

export interface IStorage {
  // Categories
  getCategories(): Promise<Category[]>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  
  // Products
  getProducts(): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  getProductsByCategory(categoryId: number): Promise<Product[]>;
  getFeaturedProducts(): Promise<Product[]>;
  searchProducts(query: string): Promise<Product[]>;
  
  // Orders
  createOrder(order: InsertOrder): Promise<Order>;
  getOrderById(id: number): Promise<Order | undefined>;
  addOrderItem(orderItem: InsertOrderItem): Promise<OrderItem>;
  getOrderItems(orderId: number): Promise<OrderItem[]>;
}

export class MemStorage implements IStorage {
  private categories: Map<number, Category>;
  private products: Map<number, Product>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem>;
  
  private categoryId: number;
  private productId: number;
  private orderId: number;
  private orderItemId: number;

  constructor() {
    this.categories = new Map();
    this.products = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    
    this.categoryId = 1;
    this.productId = 1;
    this.orderId = 1;
    this.orderItemId = 1;
    
    // Initialize with sample data
    this.initSampleData();
  }

  private initSampleData() {
    // Add categories
    const categories: InsertCategory[] = [
      { name: "Consoles", slug: "consoles", image: "https://images.unsplash.com/photo-1621259182978-fbf93132d53d" },
      { name: "Headsets", slug: "headsets", image: "https://images.unsplash.com/photo-1591390656762-d1dadabe7270" },
      { name: "Controles", slug: "controllers", image: "https://images.unsplash.com/photo-1605901309584-818e25960a8f" },
      { name: "Teclados", slug: "keyboards", image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3" },
      { name: "Mouses", slug: "mice", image: "https://images.unsplash.com/photo-1527814050087-3793815479db" }
    ];
    
    categories.forEach(category => {
      this.categories.set(this.categoryId, { 
        ...category, 
        id: this.categoryId++ 
      });
    });
    
    // Add products
    const products: InsertProduct[] = [
      {
        name: "PlayStation 5",
        description: "Console Sony de última geração com desempenho extremo para jogos e entretenimento.",
        price: "4499.90",
        image: "https://images.unsplash.com/photo-1605901309584-818e25960a8f",
        categoryId: 1,
        brand: "Sony",
        inStock: true,
        featured: true
      },
      {
        name: "Razer Kraken Pro",
        description: "Headset Gamer Razer Kraken Pro com som surround 7.1 e microfone retrátil.",
        price: "789.90",
        image: "https://images.unsplash.com/photo-1615655406736-b37c4fabf923",
        categoryId: 2,
        brand: "Razer",
        inStock: true,
        featured: true
      },
      {
        name: "Xbox Series X Controller",
        description: "Controle oficial Microsoft para Xbox Series X com conexão Bluetooth e bateria de longa duração.",
        price: "429.90",
        image: "https://images.unsplash.com/photo-1600080972464-8e5f35f63d08",
        categoryId: 3,
        brand: "Microsoft",
        inStock: true,
        featured: true
      },
      {
        name: "Logitech G Pro X",
        description: "Teclado mecânico Logitech G Pro X com switches GX Blue e iluminação RGB.",
        price: "899.90",
        image: "https://images.unsplash.com/photo-1541140532154-b024d705b90a",
        categoryId: 4,
        brand: "Logitech",
        inStock: true,
        featured: true
      },
      {
        name: "Razer DeathAdder Elite",
        description: "Mouse Gamer Razer DeathAdder Elite com sensor óptico de 16.000 DPI e iluminação RGB.",
        price: "349.90",
        image: "https://images.unsplash.com/photo-1527814050087-3793815479db",
        categoryId: 5,
        brand: "Razer",
        inStock: true,
        featured: true
      },
      {
        name: "Nintendo Switch",
        description: "Console portátil Nintendo Switch com controles Joy-Con destacáveis.",
        price: "2299.90",
        image: "https://images.unsplash.com/photo-1578303512597-81e6cc155b3e",
        categoryId: 1,
        brand: "Nintendo",
        inStock: true,
        featured: true
      },
      {
        name: "SteelSeries Arctis 7",
        description: "Headset sem fio SteelSeries Arctis 7 com som surround DTS e microfone retrátil.",
        price: "999.90",
        image: "https://images.unsplash.com/photo-1618066296858-b09f2b7fb9a5",
        categoryId: 2,
        brand: "SteelSeries",
        inStock: true,
        featured: false
      },
      {
        name: "DualShock 5",
        description: "Controle DualShock 5 para PlayStation 5 com feedback háptico e gatilhos adaptáveis.",
        price: "449.90",
        image: "https://images.unsplash.com/photo-1617096200347-cb04ae810b1d",
        categoryId: 3,
        brand: "Sony",
        inStock: true,
        featured: false
      },
      {
        name: "Corsair K100 RGB",
        description: "Teclado mecânico Corsair K100 RGB com switches Cherry MX Speed e controle de mídia dedicado.",
        price: "1299.90",
        image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3",
        categoryId: 4,
        brand: "Corsair",
        inStock: true,
        featured: false
      },
      {
        name: "Logitech G502 HERO",
        description: "Mouse Gamer Logitech G502 HERO com sensor HERO 25K e pesos ajustáveis.",
        price: "399.90",
        image: "https://images.unsplash.com/photo-1563297007-0686b7003af7",
        categoryId: 5,
        brand: "Logitech",
        inStock: true,
        featured: false
      },
      {
        name: "Xbox Series S",
        description: "Console digital Xbox Series S com resolução 1440p e armazenamento SSD de 512GB.",
        price: "2799.90",
        image: "https://images.unsplash.com/photo-1621259182978-fbf93132d53d",
        categoryId: 1,
        brand: "Microsoft",
        inStock: true,
        featured: false
      },
      {
        name: "HyperX Cloud Alpha",
        description: "Headset HyperX Cloud Alpha com drivers de câmara dupla e microfone destacável.",
        price: "599.90",
        image: "https://images.unsplash.com/photo-1591390656762-d1dadabe7270",
        categoryId: 2,
        brand: "HyperX",
        inStock: true,
        featured: false
      }
    ];
    
    products.forEach(product => {
      this.products.set(this.productId, { 
        ...product, 
        id: this.productId++ 
      });
    });
  }

  // Categories
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(
      (category) => category.slug === slug
    );
  }

  // Products
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProductById(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductsByCategory(categoryId: number): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.categoryId === categoryId
    );
  }

  async getFeaturedProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.featured
    );
  }

  async searchProducts(query: string): Promise<Product[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.products.values()).filter(
      (product) => 
        product.name.toLowerCase().includes(lowercaseQuery) || 
        product.description.toLowerCase().includes(lowercaseQuery) ||
        product.brand.toLowerCase().includes(lowercaseQuery)
    );
  }

  // Orders
  async createOrder(orderData: InsertOrder): Promise<Order> {
    const now = new Date();
    const order: Order = {
      ...orderData,
      id: this.orderId++,
      status: "pending",
      createdAt: now
    };
    this.orders.set(order.id, order);
    return order;
  }

  async getOrderById(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async addOrderItem(orderItemData: InsertOrderItem): Promise<OrderItem> {
    const orderItem: OrderItem = {
      ...orderItemData,
      id: this.orderItemId++
    };
    this.orderItems.set(orderItem.id, orderItem);
    return orderItem;
  }

  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    return Array.from(this.orderItems.values()).filter(
      (item) => item.orderId === orderId
    );
  }
}

export const storage = new MemStorage();
