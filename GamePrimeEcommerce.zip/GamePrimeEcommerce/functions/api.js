// Netlify serverless function to handle API calls
export async function handler(event, context) {
  // Base response headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  // Mock data for products
  const products = [
    {
      id: 1,
      name: "PlayStation 5",
      description: "Console Sony de última geração com desempenho extremo para jogos e entretenimento.",
      price: "4499.90",
      image: "https://images.unsplash.com/photo-1605901309584-818e25960a8f",
      categoryId: 1,
      brand: "Sony",
      inStock: true,
      featured: true
    },
    {
      id: 2,
      name: "Razer Kraken Pro",
      description: "Headset Gamer Razer Kraken Pro com som surround 7.1 e microfone retrátil.",
      price: "789.90",
      image: "https://images.unsplash.com/photo-1615655406736-b37c4fabf923",
      categoryId: 2,
      brand: "Razer",
      inStock: true,
      featured: true
    },
    {
      id: 3,
      name: "Xbox Series X Controller",
      description: "Controle oficial Microsoft para Xbox Series X com conexão Bluetooth e bateria de longa duração.",
      price: "429.90",
      image: "https://images.unsplash.com/photo-1600080972464-8e5f35f63d08",
      categoryId: 3,
      brand: "Microsoft",
      inStock: true,
      featured: true
    },
    {
      id: 4,
      name: "Logitech G Pro X",
      description: "Teclado mecânico Logitech G Pro X com switches GX Blue e iluminação RGB.",
      price: "899.90",
      image: "https://images.unsplash.com/photo-1541140532154-b024d705b90a",
      categoryId: 4,
      brand: "Logitech",
      inStock: true,
      featured: true
    },
    {
      id: 5,
      name: "Razer DeathAdder Elite",
      description: "Mouse Gamer Razer DeathAdder Elite com sensor óptico de 16.000 DPI e iluminação RGB.",
      price: "349.90",
      image: "https://images.unsplash.com/photo-1527814050087-3793815479db",
      categoryId: 5,
      brand: "Razer",
      inStock: true,
      featured: true
    },
    {
      id: 6,
      name: "Nintendo Switch",
      description: "Console portátil Nintendo Switch com controles Joy-Con destacáveis.",
      price: "2299.90",
      image: "https://images.unsplash.com/photo-1578303512597-81e6cc155b3e",
      categoryId: 1,
      brand: "Nintendo",
      inStock: true,
      featured: true
    }
  ];

  // Mock data for categories
  const categories = [
    { id: 1, name: "Consoles", slug: "consoles", image: "https://images.unsplash.com/photo-1621259182978-fbf93132d53d" },
    { id: 2, name: "Headsets", slug: "headsets", image: "https://images.unsplash.com/photo-1591390656762-d1dadabe7270" },
    { id: 3, name: "Controles", slug: "controllers", image: "https://images.unsplash.com/photo-1605901309584-818e25960a8f" },
    { id: 4, name: "Teclados", slug: "keyboards", image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3" },
    { id: 5, name: "Mouses", slug: "mice", image: "https://images.unsplash.com/photo-1527814050087-3793815479db" }
  ];

  // Mock orders storage
  let orders = [];
  let orderItems = [];
  let orderCounter = 1;
  let orderItemCounter = 1;

  // Handle CORS preflight request
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  const path = event.path.replace('/.netlify/functions/api', '');
  const segments = path.split('/').filter(segment => segment);

  try {
    // Routes
    if (event.httpMethod === 'GET' && path === '/api/categories') {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(categories)
      };
    }

    if (event.httpMethod === 'GET' && segments[0] === 'api' && segments[1] === 'categories' && segments[2]) {
      const slug = segments[2];
      const category = categories.find(c => c.slug === slug);
      
      if (!category) {
        return {
          statusCode: 404,
          headers,
          body: JSON.stringify({ message: 'Category not found' })
        };
      }
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(category)
      };
    }

    if (event.httpMethod === 'GET' && path === '/api/products') {
      // Get query parameters
      const params = event.queryStringParameters || {};
      const { category, search, featured } = params;
      
      let result = [...products];
      
      if (category) {
        const categoryObj = categories.find(c => c.slug === category);
        if (categoryObj) {
          result = result.filter(product => product.categoryId === categoryObj.id);
        } else {
          result = [];
        }
      }
      
      if (search) {
        const searchLower = search.toLowerCase();
        result = result.filter(product => 
          product.name.toLowerCase().includes(searchLower) || 
          product.description.toLowerCase().includes(searchLower) || 
          product.brand.toLowerCase().includes(searchLower)
        );
      }
      
      if (featured === 'true') {
        result = result.filter(product => product.featured);
      }
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(result)
      };
    }

    if (event.httpMethod === 'GET' && segments[0] === 'api' && segments[1] === 'products' && segments[2]) {
      const id = parseInt(segments[2]);
      if (isNaN(id)) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ message: 'Invalid product ID' })
        };
      }
      
      const product = products.find(p => p.id === id);
      if (!product) {
        return {
          statusCode: 404,
          headers,
          body: JSON.stringify({ message: 'Product not found' })
        };
      }
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(product)
      };
    }

    if (event.httpMethod === 'POST' && path === '/api/orders') {
      const body = JSON.parse(event.body);
      
      // Create new order
      const newOrder = {
        id: orderCounter++,
        customerName: body.customerName,
        email: body.email,
        address: body.address,
        city: body.city,
        state: body.state,
        postalCode: body.postalCode,
        total: body.total,
        status: 'pending',
        createdAt: new Date().toISOString()
      };
      
      orders.push(newOrder);
      
      // Add order items
      const cartItems = body.cartItems;
      if (cartItems && Array.isArray(cartItems) && cartItems.length > 0) {
        for (const item of cartItems) {
          const orderItem = {
            id: orderItemCounter++,
            orderId: newOrder.id,
            productId: item.productId,
            name: item.name,
            price: item.price.toString(),
            quantity: item.quantity
          };
          
          orderItems.push(orderItem);
        }
      }
      
      return {
        statusCode: 201,
        headers,
        body: JSON.stringify(newOrder)
      };
    }

    if (event.httpMethod === 'GET' && segments[0] === 'api' && segments[1] === 'orders' && segments[2]) {
      const id = parseInt(segments[2]);
      if (isNaN(id)) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ message: 'Invalid order ID' })
        };
      }
      
      const order = orders.find(o => o.id === id);
      if (!order) {
        return {
          statusCode: 404,
          headers,
          body: JSON.stringify({ message: 'Order not found' })
        };
      }
      
      const items = orderItems.filter(item => item.orderId === order.id);
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          order,
          items
        })
      };
    }

    // Default route - not found
    return {
      statusCode: 404,
      headers,
      body: JSON.stringify({ message: 'Not Found' })
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ message: 'Internal Server Error' })
    };
  }
}